# 💪 Motivatsiya Bot — Telegram Motivation Bot

Aiogram 3.x + APScheduler asosida yozilgan ko'p tillik kunlik motivatsiya boti.

---

## ⚡ Ishga Tushurish

### 1. `config.py` ni to'ldiring
```python
BOT_TOKEN = "7123456789:AAHxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"  # @BotFather
ADMIN_ID  = 123456789   # @userinfobot dan oling
```

### 2. Kutubxonalarni o'rnating
```bash
pip install -r requirements.txt
```

### 3. Botni ishga tushiring
```bash
python main.py
```

---

## 📂 Fayl Tuzilmasi

```
motivatsiya_bot/
├── main.py         — Handler'lar, APScheduler, FSM, dispatcher
├── buttons.py      — Reply + Inline tugmalar
├── database.py     — SQLite: users, quotes
├── config.py       — Token va sozlamalar
├── requirements.txt
├── README.md
└── locales/
    ├── uz.json     🇺🇿
    ├── ru.json     🇷🇺
    └── en.json     🇬🇧
```

---

## 👤 Foydalanuvchi Imkoniyatlari

| Tugma / Buyruq | Vazifa |
|---|---|
| 💬 Iqtibos olish / `/iqtibos` | Tasodifiy motivatsion iqtibos |
| 📂 Kategoriya tanlash | Muvaffaqiyat / Sabr / Do'stlik / Sog'liq / Biznes |
| ⏰ Kunlik eslatma / `/eslatma` | Vaqt kiritiladi (09:00), har kuni o'sha vaqtda xabar keladi |
| 🔕 Eslatmani o'chirish / `/toxtat` | Kunlik eslatmani to'xtatish |
| 🌐 Til / `/language` | UZ / RU / EN |
| ℹ️ Yordam / `/help` | Buyruqlar va admin havolasi |

---

## 👑 Admin Imkoniyatlari

`/admin` buyrug'i bilan kirish yoki `/start` dan keyin admin menyu avtomatik chiqadi.

| Tugma | Vazifa |
|---|---|
| ➕ Iqtibos qo'shish | Matn → Muallif → Kategoriya (3 bosqich) |
| 🗑️ Iqtibos o'chirish | ID bo'yicha o'chirish (so'nggi IDlar ko'rsatiladi) |
| 📊 Statistika | Foydalanuvchi / eslatma / iqtibos / kategoriya statistikasi |
| 📢 Reklama yuborish | Barcha foydalanuvchilarga xabar (tasdiqlash bilan) |

---

## ⏰ Scheduler Arxitekturasi

- **APScheduler (AsyncIOScheduler)** ishlatiladi — aiogram event loop bilan bir xilda ishlaydi.
- Timezone: `Asia/Tashkent` — config.py da o'zgartirib qo'yish mumkin.
- Bot qayta ishga tushganda DB dagi barcha eslatmalar avtomatik tiklanadi.
- Har bir vaqt (HH:MM) uchun bitta `CronTrigger` job yaratiladi — xotira tejiladi.
- Foydalanuvchi eslatma o'rnatsa: DB ga saqlanadi + scheduler ga job qo'shiladi.

---

## 🗄️ Ma'lumotlar Bazasi

- **users** — user_id, til, eslatma vaqti (HH:MM | NULL)
- **quotes** — id, matn, muallif, kategoriya

Bot birinchi marta ishga tushganda **25 ta namunaviy iqtibos** avtomatik qo'shiladi.

---

## 🌐 Kategoriyalar

| Key | UZ | RU | EN |
|---|---|---|---|
| success | 🏆 Muvaffaqiyat | 🏆 Успех | 🏆 Success |
| patience | 🧘 Sabr | 🧘 Терпение | 🧘 Patience |
| friendship | 🤝 Do'stlik | 🤝 Дружба | 🤝 Friendship |
| health | 💪 Sog'liq | 💪 Здоровье | 💪 Health |
| business | 💼 Biznes | 💼 Бизнес | 💼 Business |

Yangi kategoriya qo'shish: `config.py` dagi `CATEGORIES` ga qo'shing va barcha `locales/*.json` ga `cat_<key>` ni qo'shing.

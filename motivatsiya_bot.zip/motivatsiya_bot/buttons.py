# =============================================
# buttons.py — Barcha tugmalar
# =============================================

from aiogram.types import (
    ReplyKeyboardMarkup, KeyboardButton,
    InlineKeyboardMarkup, InlineKeyboardButton,
    ReplyKeyboardRemove
)
from aiogram.utils.keyboard import ReplyKeyboardBuilder, InlineKeyboardBuilder
from config import CATEGORIES


# ──────────────────────────────────────────
# FOYDALANUVCHI — asosiy menyu
# ──────────────────────────────────────────

def user_main_kb(t: dict) -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(
        KeyboardButton(text=t["btn_get_quote"]),
        KeyboardButton(text=t["btn_category"])
    )
    builder.row(
        KeyboardButton(text=t["btn_set_reminder"]),
        KeyboardButton(text=t["btn_stop_reminder"])
    )
    builder.row(
        KeyboardButton(text=t["btn_language"]),
        KeyboardButton(text=t["btn_help"])
    )
    return builder.as_markup(resize_keyboard=True)


# ──────────────────────────────────────────
# ADMIN — asosiy menyu
# ──────────────────────────────────────────

def admin_main_kb(t: dict) -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(
        KeyboardButton(text=t["btn_add_quote"]),
        KeyboardButton(text=t["btn_delete_quote"])
    )
    builder.row(
        KeyboardButton(text=t["btn_stats"]),
        KeyboardButton(text=t["btn_broadcast"])
    )
    builder.row(KeyboardButton(text=t["btn_back"]))
    return builder.as_markup(resize_keyboard=True)


# ──────────────────────────────────────────
# KATEGORIYALAR — InlineKeyboard
# ──────────────────────────────────────────

def categories_kb(t: dict) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for cat in CATEGORIES:
        builder.row(InlineKeyboardButton(
            text=t.get(f"cat_{cat}", cat.capitalize()),
            callback_data=f"cat:{cat}"
        ))
    return builder.as_markup()


def admin_categories_kb(t: dict) -> InlineKeyboardMarkup:
    """Savol qo'shishda kategoriya tanlash."""
    builder = InlineKeyboardBuilder()
    for cat in CATEGORIES:
        builder.row(InlineKeyboardButton(
            text=t.get(f"cat_{cat}", cat.capitalize()),
            callback_data=f"addcat:{cat}"
        ))
    return builder.as_markup()


# ──────────────────────────────────────────
# TIL TANLASH
# ──────────────────────────────────────────

def language_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🇺🇿 O'zbekcha", callback_data="lang:uz"),
        InlineKeyboardButton(text="🇷🇺 Русский",   callback_data="lang:ru"),
        InlineKeyboardButton(text="🇬🇧 English",   callback_data="lang:en"),
    )
    return builder.as_markup()


# ──────────────────────────────────────────
# TASDIQLASH
# ──────────────────────────────────────────

def confirm_kb(confirm_cb: str, cancel_cb: str, t: dict) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text=t["btn_confirm"], callback_data=confirm_cb),
        InlineKeyboardButton(text=t["btn_cancel"],  callback_data=cancel_cb)
    )
    return builder.as_markup()


def remove_kb() -> ReplyKeyboardRemove:
    return ReplyKeyboardRemove()

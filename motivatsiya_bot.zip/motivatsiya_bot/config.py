# =============================================
# config.py — Bot sozlamalari
# =============================================

BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"   # @BotFather dan
ADMIN_ID  = 123456789               # Sizning Telegram ID (@userinfobot)

DB_PATH   = "motivatsiya.db"

# Kategoriyalar (DB va locale key sifatida ishlatiladi)
CATEGORIES = ["success", "patience", "friendship", "health", "business"]

# =============================================
# database.py — SQLite ma'lumotlar bazasi
# =============================================

import sqlite3
from config import DB_PATH, CATEGORIES


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """Barcha jadvallarni yaratish va namunaviy iqtiboslarni to'ldirish."""
    conn = get_conn()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id     INTEGER PRIMARY KEY,
            username    TEXT,
            full_name   TEXT,
            language    TEXT    DEFAULT 'uz',
            reminder    TEXT,           -- "HH:MM" yoki NULL
            created_at  TEXT    DEFAULT (datetime('now'))
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS quotes (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            text        TEXT    NOT NULL,
            author      TEXT    NOT NULL DEFAULT 'Noma''lum',
            category    TEXT    NOT NULL,   -- 'success' | 'patience' | ...
            created_at  TEXT    DEFAULT (datetime('now'))
        )
    """)

    conn.commit()

    # Namunaviy iqtiboslar (DB bo'sh bo'lsa qo'shamiz)
    count = conn.execute("SELECT COUNT(*) FROM quotes").fetchone()[0]
    if count == 0:
        _seed_quotes(conn)

    conn.close()


def _seed_quotes(conn: sqlite3.Connection):
    """Boshlang'ich iqtiboslar to'plami."""
    samples = [
        # Muvaffaqiyat
        ("Muvaffaqiyat — bu tasodif emas, bu mehnat, qat'iyat va sabr natijasidir.", "Pele", "success"),
        ("Imkonsiz deb atalgan narsalar shunchaki hali amalga oshirilmagan narsalardir.", "Bruce Lee", "success"),
        ("Katta orzular ko'ring, ular xayolotingizni emas, qalbingizni to'ldirsin.", "Ronald Reagan", "success"),
        ("Har bir yangi kun — yangi imkoniyat.", "Noma'lum", "success"),
        ("Мuvaffaqiyat — bu maqsadga qadam-qadam yaqinlashishdir.", "Brian Tracy", "success"),

        # Sabr
        ("Sabr — barcha eshiklarni ochadigan kalit.", "Noma'lum", "patience"),
        ("Vaqt va sabr — eng kuchli jangchilar.", "Lev Tolstoy", "patience"),
        ("Toshni yaran suv emas, uning tinim bilmasligi.", "Publilius Syrus", "patience"),
        ("Sabr qiluvchi kishi istagan narsasiga erishadi.", "Benjamin Franklin", "patience"),
        ("Qiyin paytlarda chidamlilik — buyuklikning belgisidir.", "Noma'lum", "patience"),

        # Do'stlik
        ("Haqiqiy do'st — bu ikki tanada yashovchi bir jon.", "Aristotel", "friendship"),
        ("Do'stlik — bu bir qalbning ikki badanda yashashidir.", "Noma'lum", "friendship"),
        ("Yaxshi do'st topish — katta boylik.", "Noma'lum", "friendship"),
        ("Bahtsizlikda bilinar do'st.", "Noma'lum", "friendship"),
        ("Do'stlaringiz siz haqingizda ko'p narsa aytib beradi.", "Noma'lum", "friendship"),

        # Sog'liq
        ("Sog'liq — eng katta boylik.", "Virgilius", "health"),
        ("Sog'lom tanda — sog'lom aql.", "Yuvenal", "health"),
        ("Kasallikni oldini olish uni davolashdan yaxshiroqdir.", "Noma'lum", "health"),
        ("Har kuni harakat qiling — tana va aql uchun.", "Noma'lum", "health"),
        ("Uyqu, harakat va ovqat — sog'likning uch ustuni.", "Noma'lum", "health"),

        # Biznes
        ("Biznesingizni sevishingiz kerak, aks holda u sizni sevmaydi.", "Noma'lum", "business"),
        ("Xavf olmagan kishi hech narsaga erisha olmaydi.", "Noma'lum", "business"),
        ("Eng yaxshi investitsiya — o'z-o'zingizga investitsiya.", "Warren Buffett", "business"),
        ("Muvaffaqiyatli odamlar imkoniyat izlaydi, boshqalar esa bahona.", "Noma'lum", "business"),
        ("Katta o'ylang, kichikdan boshlang, tez harakat qiling.", "Eric Ries", "business"),
    ]
    conn.executemany(
        "INSERT INTO quotes (text, author, category) VALUES (?, ?, ?)",
        samples
    )
    conn.commit()


# ──────────────────────────────────────────
# FOYDALANUVCHILAR
# ──────────────────────────────────────────

def upsert_user(user_id: int, username: str, full_name: str):
    conn = get_conn()
    conn.execute("""
        INSERT INTO users (user_id, username, full_name)
        VALUES (?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
            username  = excluded.username,
            full_name = excluded.full_name
    """, (user_id, username or "", full_name or ""))
    conn.commit()
    conn.close()


def get_user(user_id: int) -> dict | None:
    conn = get_conn()
    row = conn.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_user_language(user_id: int) -> str:
    conn = get_conn()
    row = conn.execute("SELECT language FROM users WHERE user_id = ?", (user_id,)).fetchone()
    conn.close()
    return (row["language"] if row else None) or "uz"


def set_user_language(user_id: int, lang: str):
    conn = get_conn()
    conn.execute("UPDATE users SET language = ? WHERE user_id = ?", (lang, user_id))
    conn.commit()
    conn.close()


def get_all_users() -> list[dict]:
    conn = get_conn()
    rows = conn.execute("SELECT * FROM users").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def count_users() -> int:
    conn = get_conn()
    val = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    conn.close()
    return val


# ──────────────────────────────────────────
# ESLATMALAR
# ──────────────────────────────────────────

def set_reminder(user_id: int, time_str: str):
    """'HH:MM' formatida eslatma saqlash."""
    conn = get_conn()
    conn.execute("UPDATE users SET reminder = ? WHERE user_id = ?", (time_str, user_id))
    conn.commit()
    conn.close()


def clear_reminder(user_id: int):
    conn = get_conn()
    conn.execute("UPDATE users SET reminder = NULL WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()


def get_reminder(user_id: int) -> str | None:
    conn = get_conn()
    row = conn.execute("SELECT reminder FROM users WHERE user_id = ?", (user_id,)).fetchone()
    conn.close()
    return row["reminder"] if row else None


def get_users_by_reminder(time_str: str) -> list[dict]:
    """Berilgan vaqtga eslatma o'rnatgan barcha foydalanuvchilar."""
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM users WHERE reminder = ?", (time_str,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def count_active_reminders() -> int:
    conn = get_conn()
    val = conn.execute("SELECT COUNT(*) FROM users WHERE reminder IS NOT NULL").fetchone()[0]
    conn.close()
    return val


# ──────────────────────────────────────────
# IQTIBOSLAR
# ──────────────────────────────────────────

def add_quote(text: str, author: str, category: str) -> int:
    """Yangi iqtibos qo'shish. Qaytaradi: yangi ID."""
    conn = get_conn()
    cur = conn.execute(
        "INSERT INTO quotes (text, author, category) VALUES (?, ?, ?)",
        (text, author, category)
    )
    new_id = cur.lastrowid
    conn.commit()
    conn.close()
    return new_id


def get_random_quote(category: str | None = None) -> dict | None:
    conn = get_conn()
    if category:
        row = conn.execute(
            "SELECT * FROM quotes WHERE category = ? ORDER BY RANDOM() LIMIT 1",
            (category,)
        ).fetchone()
    else:
        row = conn.execute(
            "SELECT * FROM quotes ORDER BY RANDOM() LIMIT 1"
        ).fetchone()
    conn.close()
    return dict(row) if row else None


def get_quote_by_id(quote_id: int) -> dict | None:
    conn = get_conn()
    row = conn.execute("SELECT * FROM quotes WHERE id = ?", (quote_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def delete_quote(quote_id: int) -> bool:
    conn = get_conn()
    cur = conn.execute("DELETE FROM quotes WHERE id = ?", (quote_id,))
    conn.commit()
    conn.close()
    return cur.rowcount > 0


def count_quotes() -> int:
    conn = get_conn()
    val = conn.execute("SELECT COUNT(*) FROM quotes").fetchone()[0]
    conn.close()
    return val


def get_recent_quote_ids(limit: int = 10) -> list[int]:
    conn = get_conn()
    rows = conn.execute(
        "SELECT id FROM quotes ORDER BY id DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return [r["id"] for r in rows]


def get_category_stats() -> dict[str, int]:
    conn = get_conn()
    rows = conn.execute(
        "SELECT category, COUNT(*) AS cnt FROM quotes GROUP BY category"
    ).fetchall()
    conn.close()
    return {r["category"]: r["cnt"] for r in rows}

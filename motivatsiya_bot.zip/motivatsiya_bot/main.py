# =============================================
# main.py — Handler'lar, APScheduler, FSM, dispatcher
# =============================================

import asyncio
import json
import logging
import re
from pathlib import Path
from datetime import datetime

from aiogram import Bot, Dispatcher, F, Router
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import Message, CallbackQuery, ReplyKeyboardRemove

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from config import BOT_TOKEN, ADMIN_ID, CATEGORIES
import database as db
import buttons as kb

# ──────────────────────────────────────────
# Logging
# ──────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s"
)
logger = logging.getLogger(__name__)

# ──────────────────────────────────────────
# Locales
# ──────────────────────────────────────────
LOCALES: dict[str, dict] = {}


def load_locales():
    locale_dir = Path(__file__).parent / "locales"
    for lang in ("uz", "ru", "en"):
        with open(locale_dir / f"{lang}.json", encoding="utf-8") as f:
            LOCALES[lang] = json.load(f)


def loc(user_id: int) -> dict:
    lang = db.get_user_language(user_id)
    return LOCALES.get(lang, LOCALES["uz"])


def tr(user_id: int, key: str, **kwargs) -> str:
    text = loc(user_id).get(key, key)
    if kwargs:
        try:
            text = text.format(**kwargs)
        except KeyError:
            pass
    return text


# ──────────────────────────────────────────
# Scheduler (global, botga bog'laymiz)
# ──────────────────────────────────────────
scheduler = AsyncIOScheduler(timezone="Asia/Tashkent")

# ──────────────────────────────────────────
# FSM holatlari
# ──────────────────────────────────────────

class ReminderState(StatesGroup):
    waiting_time = State()


class AdminAddQuote(StatesGroup):
    waiting_text     = State()
    waiting_author   = State()
    waiting_category = State()   # InlineKeyboard orqali


class AdminDeleteQuote(StatesGroup):
    waiting_id = State()


class AdminBroadcast(StatesGroup):
    typing_msg = State()
    confirming = State()


# ──────────────────────────────────────────
# Router
# ──────────────────────────────────────────
router = Router()

# ──────────────────────────────────────────
# YORDAMCHI
# ──────────────────────────────────────────

def is_admin(uid: int) -> bool:
    return uid == ADMIN_ID


TIME_RE = re.compile(r"^([01]\d|2[0-3]):([0-5]\d)$")


def parse_time(text: str) -> tuple[int, int] | None:
    """HH:MM formatini tekshirish. (soat, daqiqa) yoki None."""
    m = TIME_RE.match(text.strip())
    if not m:
        return None
    return int(m.group(1)), int(m.group(2))


async def send_main_menu(message: Message, uid: int):
    l = loc(uid)
    if is_admin(uid):
        await message.answer(l["admin_choose"], reply_markup=kb.admin_main_kb(l))
    else:
        await message.answer(l["choose_action"], reply_markup=kb.user_main_kb(l))


def format_quote(q: dict, t: dict) -> str:
    return t["quote_msg"].format(text=q["text"], author=q["author"])


def btn_matches(text: str, key: str) -> bool:
    return any(LOCALES[lang].get(key) == text for lang in LOCALES)


# ──────────────────────────────────────────
# SCHEDULER — kunlik eslatma yuborish
# ──────────────────────────────────────────

async def send_daily_reminders(bot: Bot, hour: int, minute: int):
    """Har daqiqada ishga tushadi; o'sha vaqtga registered userlar topiladi."""
    time_str = f"{hour:02d}:{minute:02d}"
    users = db.get_users_by_reminder(time_str)
    if not users:
        return

    logger.info(f"[scheduler] {time_str} — {len(users)} ta foydalanuvchiga eslatma yuborilmoqda")
    for user in users:
        quote = db.get_random_quote()
        if not quote:
            continue
        l = LOCALES.get(user.get("language", "uz"), LOCALES["uz"])
        text = l["daily_reminder"].format(text=quote["text"], author=quote["author"])
        try:
            await bot.send_message(user["user_id"], text, parse_mode=ParseMode.HTML)
        except Exception as e:
            logger.warning(f"[scheduler] user {user['user_id']} ga yuborib bo'lmadi: {e}")


def register_reminder_job(bot: Bot, hour: int, minute: int):
    """Har bir daqiqa uchun (HH:MM) alohida job qo'shiladi.
    Agar bunday job allaqachon mavjud bo'lsa — qaytadan qo'shilmaydi."""
    job_id = f"reminder_{hour:02d}_{minute:02d}"
    if scheduler.get_job(job_id):
        return  # allaqachon mavjud
    scheduler.add_job(
        send_daily_reminders,
        trigger=CronTrigger(hour=hour, minute=minute),
        args=[bot, hour, minute],
        id=job_id,
        replace_existing=True
    )
    logger.info(f"[scheduler] job qo'shildi: {hour:02d}:{minute:02d}")


def restore_reminder_jobs(bot: Bot):
    """Bot qayta ishga tushganda DB dan barcha eslatmalarni qayta ro'yxatga olish."""
    users = db.get_all_users()
    times_seen = set()
    for user in users:
        t = user.get("reminder")
        if t and t not in times_seen:
            h, m = int(t[:2]), int(t[3:])
            register_reminder_job(bot, h, m)
            times_seen.add(t)
    logger.info(f"[scheduler] {len(times_seen)} ta vaqt tiklandi")


# ══════════════════════════════════════════
# /start
# ══════════════════════════════════════════

@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()
    user = message.from_user
    db.upsert_user(user.id, user.username, user.full_name)
    l = loc(user.id)
    await message.answer(
        l["welcome"].format(name=user.first_name),
        reply_markup=ReplyKeyboardRemove()
    )
    await send_main_menu(message, user.id)


# ══════════════════════════════════════════
# /iqtibos — tasodifiy iqtibos
# ══════════════════════════════════════════

@router.message(Command("iqtibos"))
async def cmd_iqtibos(message: Message, state: FSMContext):
    await state.clear()
    uid = message.from_user.id
    quote = db.get_random_quote()
    l = loc(uid)
    if not quote:
        await message.answer(l["no_quotes"])
        return
    await message.answer(
        l["random_quote"] + "\n\n" + format_quote(quote, l),
        parse_mode=ParseMode.HTML
    )


# ══════════════════════════════════════════
# /eslatma — eslatma vaqtini o'rnatish
# ══════════════════════════════════════════

@router.message(Command("eslatma"))
async def cmd_eslatma(message: Message, state: FSMContext):
    await state.clear()
    uid = message.from_user.id
    existing = db.get_reminder(uid)
    if existing:
        await message.answer(
            tr(uid, "reminder_already", time=existing),
            parse_mode=ParseMode.HTML
        )
        return
    await state.set_state(ReminderState.waiting_time)
    await message.answer(tr(uid, "reminder_set_prompt"), parse_mode=ParseMode.HTML)


# ══════════════════════════════════════════
# /toxtat — eslatmani to'xtatish
# ══════════════════════════════════════════

@router.message(Command("toxtat"))
async def cmd_toxtat(message: Message, state: FSMContext):
    await state.clear()
    uid = message.from_user.id
    existing = db.get_reminder(uid)
    if not existing:
        await message.answer(tr(uid, "reminder_none"))
        return
    db.clear_reminder(uid)
    l = loc(uid)
    await message.answer(l["reminder_stopped"], reply_markup=kb.user_main_kb(l))


# ══════════════════════════════════════════
# /language
# ══════════════════════════════════════════

@router.message(Command("language"))
async def cmd_language(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(LOCALES["uz"]["choose_language"], reply_markup=kb.language_kb())


@router.callback_query(F.data.startswith("lang:"))
async def cb_language(call: CallbackQuery, state: FSMContext):
    await state.clear()
    lang = call.data.split(":")[1]
    db.set_user_language(call.from_user.id, lang)
    l = LOCALES[lang]
    await call.message.edit_text(l["language_set"])
    await call.message.answer(l["choose_action"], reply_markup=kb.user_main_kb(l))
    await call.answer()


# ══════════════════════════════════════════
# /help
# ══════════════════════════════════════════

@router.message(Command("help"))
async def cmd_help(message: Message):
    uid = message.from_user.id
    await message.answer(
        tr(uid, "help_text", admin_link=f"tg://user?id={ADMIN_ID}"),
        parse_mode=ParseMode.HTML
    )


# ══════════════════════════════════════════
# /admin
# ══════════════════════════════════════════

@router.message(Command("admin"))
async def cmd_admin(message: Message, state: FSMContext):
    await state.clear()
    uid = message.from_user.id
    if not is_admin(uid):
        await message.answer(tr(uid, "not_admin"))
        return
    l = loc(uid)
    await message.answer(l["admin_welcome"], reply_markup=kb.admin_main_kb(l))


# ══════════════════════════════════════════
# FSM — ESLATMA VAQTI
# ══════════════════════════════════════════

@router.message(ReminderState.waiting_time)
async def fsm_reminder_time(message: Message, state: FSMContext):
    uid = message.from_user.id
    parsed = parse_time(message.text)
    if parsed is None:
        await message.answer(tr(uid, "reminder_invalid"), parse_mode=ParseMode.HTML)
        return

    hour, minute = parsed
    time_str = f"{hour:02d}:{minute:02d}"
    db.set_reminder(uid, time_str)

    # Scheduler ga job qo'shamiz (agar yo'q bo'lsa)
    bot: Bot = message.bot
    register_reminder_job(bot, hour, minute)

    await state.clear()
    l = loc(uid)
    await message.answer(
        tr(uid, "reminder_set", time=time_str),
        parse_mode=ParseMode.HTML,
        reply_markup=kb.user_main_kb(l)
    )


# ══════════════════════════════════════════
# TUGMA HANDLER'LARI — Foydalanuvchi
# ══════════════════════════════════════════

# 💬 Iqtibos olish
@router.message(F.text.func(lambda t: btn_matches(t, "btn_get_quote")))
async def btn_get_quote(message: Message, state: FSMContext):
    await state.clear()
    await cmd_iqtibos(message, state)


# 📂 Kategoriya tanlash
@router.message(F.text.func(lambda t: btn_matches(t, "btn_category")))
async def btn_category(message: Message, state: FSMContext):
    await state.clear()
    uid = message.from_user.id
    l = loc(uid)
    await message.answer(l["choose_category"], reply_markup=kb.categories_kb(l))


@router.callback_query(F.data.startswith("cat:"))
async def cb_category(call: CallbackQuery, state: FSMContext):
    await state.clear()
    uid = call.from_user.id
    cat = call.data.split(":")[1]
    quote = db.get_random_quote(category=cat)
    l = loc(uid)
    cat_name = l.get(f"cat_{cat}", cat)
    if not quote:
        await call.answer(l["no_quotes_in_cat"], show_alert=True)
        return
    await call.message.edit_text(
        l["category_quote"].format(category=cat_name) + "\n\n" + format_quote(quote, l),
        parse_mode=ParseMode.HTML
    )
    await call.answer()


# ⏰ Kunlik eslatma
@router.message(F.text.func(lambda t: btn_matches(t, "btn_set_reminder")))
async def btn_set_reminder(message: Message, state: FSMContext):
    await state.clear()
    uid = message.from_user.id
    existing = db.get_reminder(uid)
    if existing:
        await message.answer(
            tr(uid, "reminder_already", time=existing),
            parse_mode=ParseMode.HTML
        )
        return
    await state.set_state(ReminderState.waiting_time)
    await message.answer(tr(uid, "reminder_set_prompt"), parse_mode=ParseMode.HTML)


# 🔕 Eslatmani o'chirish
@router.message(F.text.func(lambda t: btn_matches(t, "btn_stop_reminder")))
async def btn_stop_reminder(message: Message, state: FSMContext):
    await state.clear()
    await cmd_toxtat(message, state)


# 🌐 Til
@router.message(F.text.func(lambda t: btn_matches(t, "btn_language")))
async def btn_language(message: Message, state: FSMContext):
    await state.clear()
    await cmd_language(message, state)


# ℹ️ Yordam
@router.message(F.text.func(lambda t: btn_matches(t, "btn_help")))
async def btn_help(message: Message, state: FSMContext):
    await state.clear()
    await cmd_help(message)


# ⬅️ Orqaga (admin → user menyu)
@router.message(F.text.func(lambda t: btn_matches(t, "btn_back")))
async def btn_back(message: Message, state: FSMContext):
    await state.clear()
    uid = message.from_user.id
    l = loc(uid)
    await message.answer(l["choose_action"], reply_markup=kb.user_main_kb(l))


# ❌ Bekor qilish
@router.message(F.text.func(lambda t: btn_matches(t, "btn_cancel")))
async def btn_cancel(message: Message, state: FSMContext):
    await state.clear()
    uid = message.from_user.id
    l = loc(uid)
    await message.answer(l["cancelled"], reply_markup=kb.user_main_kb(l))


# ══════════════════════════════════════════
# TUGMA HANDLER'LARI — Admin
# ══════════════════════════════════════════

# ➕ Iqtibos qo'shish
@router.message(F.text.func(lambda t: btn_matches(t, "btn_add_quote")))
async def btn_add_quote(message: Message, state: FSMContext):
    uid = message.from_user.id
    if not is_admin(uid):
        await message.answer(tr(uid, "not_admin"))
        return
    await state.set_state(AdminAddQuote.waiting_text)
    await message.answer(tr(uid, "add_quote_step1"), reply_markup=kb.remove_kb())


@router.message(AdminAddQuote.waiting_text)
async def fsm_quote_text(message: Message, state: FSMContext):
    await state.update_data(quote_text=message.text.strip())
    await state.set_state(AdminAddQuote.waiting_author)
    await message.answer(tr(message.from_user.id, "add_quote_step2"))


@router.message(AdminAddQuote.waiting_author)
async def fsm_quote_author(message: Message, state: FSMContext):
    uid = message.from_user.id
    await state.update_data(quote_author=message.text.strip())
    await state.set_state(AdminAddQuote.waiting_category)
    l = loc(uid)
    await message.answer(l["add_quote_step3"], reply_markup=kb.admin_categories_kb(l))


@router.callback_query(AdminAddQuote.waiting_category, F.data.startswith("addcat:"))
async def cb_quote_category(call: CallbackQuery, state: FSMContext):
    uid = call.from_user.id
    cat = call.data.split(":")[1]
    data = await state.get_data()
    text   = data["quote_text"]
    author = data["quote_author"]

    db.add_quote(text, author, cat)
    await state.clear()

    l = loc(uid)
    cat_name = l.get(f"cat_{cat}", cat)
    await call.message.edit_text(
        tr(uid, "quote_added", text=text, author=author, category=cat_name),
        parse_mode=ParseMode.HTML
    )
    await call.message.answer(l["admin_choose"], reply_markup=kb.admin_main_kb(l))
    await call.answer()


# 🗑️ Iqtibos o'chirish
@router.message(F.text.func(lambda t: btn_matches(t, "btn_delete_quote")))
async def btn_delete_quote(message: Message, state: FSMContext):
    uid = message.from_user.id
    if not is_admin(uid):
        await message.answer(tr(uid, "not_admin"))
        return
    ids = db.get_recent_quote_ids(10)
    ids_str = ", ".join(str(i) for i in ids) if ids else "—"
    await state.set_state(AdminDeleteQuote.waiting_id)
    await message.answer(
        tr(uid, "delete_quote_prompt", ids=ids_str),
        parse_mode=ParseMode.HTML,
        reply_markup=kb.remove_kb()
    )


@router.message(AdminDeleteQuote.waiting_id)
async def fsm_delete_quote(message: Message, state: FSMContext):
    uid = message.from_user.id
    l = loc(uid)
    try:
        quote_id = int(message.text.strip())
    except ValueError:
        await message.answer(tr(uid, "quote_not_found", id=message.text.strip()), parse_mode=ParseMode.HTML)
        return

    deleted = db.delete_quote(quote_id)
    await state.clear()
    if deleted:
        await message.answer(tr(uid, "quote_deleted", id=quote_id), reply_markup=kb.admin_main_kb(l))
    else:
        await message.answer(tr(uid, "quote_not_found", id=quote_id), parse_mode=ParseMode.HTML,
                             reply_markup=kb.admin_main_kb(l))


# 📊 Statistika
@router.message(F.text.func(lambda t: btn_matches(t, "btn_stats")))
async def btn_stats(message: Message):
    uid = message.from_user.id
    if not is_admin(uid):
        await message.answer(tr(uid, "not_admin"))
        return
    l = loc(uid)
    cat_counts = db.get_category_stats()
    cat_text = ""
    for cat in CATEGORIES:
        name = l.get(f"cat_{cat}", cat)
        count = cat_counts.get(cat, 0)
        cat_text += l["cat_stat_row"].format(name=name, count=count)

    await message.answer(
        tr(uid, "stats",
           users=db.count_users(),
           reminders=db.count_active_reminders(),
           quotes=db.count_quotes(),
           cat_stats=cat_text or "—"),
        parse_mode=ParseMode.HTML
    )


# 📢 Reklama yuborish
@router.message(F.text.func(lambda t: btn_matches(t, "btn_broadcast")))
async def btn_broadcast(message: Message, state: FSMContext):
    uid = message.from_user.id
    if not is_admin(uid):
        await message.answer(tr(uid, "not_admin"))
        return
    await state.set_state(AdminBroadcast.typing_msg)
    await message.answer(tr(uid, "broadcast_prompt"), reply_markup=kb.remove_kb())


@router.message(AdminBroadcast.typing_msg)
async def fsm_broadcast_text(message: Message, state: FSMContext):
    uid = message.from_user.id
    text = message.text.strip()
    users = db.get_all_users()
    l = loc(uid)
    await state.update_data(broadcast_text=text)
    await state.set_state(AdminBroadcast.confirming)
    await message.answer(
        tr(uid, "broadcast_confirm", count=len(users), text=text),
        parse_mode=ParseMode.HTML,
        reply_markup=kb.confirm_kb("bcast_yes", "bcast_no", l)
    )


@router.callback_query(AdminBroadcast.confirming, F.data == "bcast_yes")
async def cb_broadcast_yes(call: CallbackQuery, state: FSMContext):
    uid = call.from_user.id
    data = await state.get_data()
    text = data["broadcast_text"]
    await state.clear()
    users = db.get_all_users()
    bot: Bot = call.bot
    sent = 0
    for user in users:
        try:
            await bot.send_message(user["user_id"], text)
            sent += 1
        except Exception:
            pass
    l = loc(uid)
    await call.message.edit_text(tr(uid, "broadcast_sent", sent=sent, total=len(users)))
    await call.message.answer(l["admin_choose"], reply_markup=kb.admin_main_kb(l))
    await call.answer()


@router.callback_query(AdminBroadcast.confirming, F.data == "bcast_no")
async def cb_broadcast_no(call: CallbackQuery, state: FSMContext):
    uid = call.from_user.id
    await state.clear()
    l = loc(uid)
    await call.message.edit_text(tr(uid, "broadcast_cancelled"))
    await call.message.answer(l["admin_choose"], reply_markup=kb.admin_main_kb(l))
    await call.answer()


# ══════════════════════════════════════════
# NOMA'LUM XABAR
# ══════════════════════════════════════════

@router.message()
async def unknown(message: Message, state: FSMContext):
    uid = message.from_user.id
    current = await state.get_state()
    if not current:
        await send_main_menu(message, uid)


# ══════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════

async def main():
    load_locales()
    db.init_db()

    bot = Bot(token=BOT_TOKEN, parse_mode=ParseMode.HTML)
    dp  = Dispatcher(storage=MemoryStorage())
    dp.include_router(router)

    # DB dagi eslatmalarni scheduler ga yuklash
    restore_reminder_jobs(bot)
    scheduler.start()
    logger.info("Scheduler ishga tushdi ✅")

    logger.info("Motivatsiya Bot ishga tushdi ✅")
    try:
        await dp.start_polling(bot, allowed_updates=["message", "callback_query"])
    finally:
        scheduler.shutdown()
        logger.info("Scheduler to'xtatildi.")


if __name__ == "__main__":
    asyncio.run(main())
